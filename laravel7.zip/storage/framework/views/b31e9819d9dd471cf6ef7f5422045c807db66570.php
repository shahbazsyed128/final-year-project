
<?php $__env->startSection('content'); ?>
  <!-- Content Header (Page header) -->
<div class="container-fluid">
  <div class="content-header">
      <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Registered Categories</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="breadcrumb-item active">Categories</li>
                </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
      </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->
  <div class="card">
    <div class="card-header">
    <div class="float-right">
      <a href="#" data-toggle="modal" data-target="#AddNewCategory" class="btn btn-primary"><i class="fas fa-plus"></i></a>
    </div>
    </div>
    <div class="card-body p-0">
      <table class="table table-hover table-striped ">
        <thead>
          <tr>
            <th style="width: 10px">#</th>
            <th>Name</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
        <?php if(count($data)>0): ?>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($category->name); ?></td>
         
            <td>
            <div class="flex">
             
            <a href="#" data-toggle="modal" data-target="#EditCategory"  onclick="EditModal(<?php echo e($category->id); ?>)"><i class="fa fa-edit"></i></a> | 

              <form action="<?php echo e(route('categories.destroy',$category->id)); ?>" class=" d-inline" method="POST" id="deletecategory<?php echo e($category->id); ?>"> 
                 <?php echo csrf_field(); ?>
                 <?php echo method_field('DELETE'); ?>
              <button type="button"  onclick="ConfirmDelete(<?php echo e($category->id); ?>)" class="bg-transparent  border-0" ><i class=" text-danger fa fa-trash" aria-hidden="true"></i></button>  
              </form>
              
            </div>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
        <tr>
          <th colspan="3" class="bg-light"><p class="text-center text-primary mb-0">There is no Registered Categories</p></th>
        </tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
    <!-- /.card-body -->
    <div class="card-footer clearfix">
    
      <ul class="pagination pagination-sm m-0 float-right">
      <?php echo e($data->links()); ?>

      </ul>
    </div>
  </div>

  <div class="modal fade" id="EditCategory" tabindex="-1" aria-labelledby="EditCategory" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"  id="AddNewCategoryLabel">Edit Category</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="editcategoryform" action="" method="post">
                    <?php echo e(csrf_field()); ?>

                        <div class="modal-body">
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" name="name"  id="cat-name" required  placeholder="Enter Category Name" class="form-control" >
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        
                            <button type="submit"  class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
  </div>
  <div class="modal fade" id="AddNewCategory" tabindex="-1" aria-labelledby="AddNewCategoryLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"  id="AddNewCategoryLabel">Add New Category</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="addcategoryform" action="<?php echo e(route('addcategory')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                        <div class="modal-body">
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" name="name"  required value="<?php echo e(old('name')); ?>"  placeholder="Enter Category Name" class="form-control" >
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        
                            <button type="submit"  class="btn btn-primary">Create</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
 function EditModal(id) {
    $('#editcategoryform').attr('action', "<?php echo e(url('/categories/update/')); ?>/"+id);

      $.ajax({
          type: "GET",
          url: "<?php echo e(url('/categories/edit/')); ?>/"+id,
          success: function(data) {
              // console.log(data.name);
              $("#cat-name").val(data.name);
          }
      });

 }

function ConfirmDelete(id) {
        Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then((result) => {
        if (result.isConfirmed) {
          Swal.fire(
            'Deleted!',
            'Your Record has been deleted.',
            'success'
          );
          $("#deletecategory"+id).submit();

        }
      })
  }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\resources\views/categories/categories.blade.php ENDPATH**/ ?>