
<?php $__env->startSection('content'); ?>
  <!-- Content Header (Page header) -->
<div class="container-fluid">
 
  <div class="content-header">
      <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Registered Users</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="/home">Home</a></li>
                <li class="breadcrumb-item active">Users</li>
                </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
      </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->
  <div class="card">
    <div class="card-header">
      <div class="float-right">
      
        <a href="#" data-toggle="modal" data-target="#AddNewUser" class="btn btn-primary"><i class="fas fa-user-plus"></i></a>
      </div>
    </div>
    <div class="card-body p-0">
      <table class="table table-hover table-striped ">
        <thead>
          <tr>
            <th style="width: 10px">#</th>
            <th>Name</th>
            <th>Email</th>
            <th style="width: 40px">Role</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>

          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td> <?php if($user->status): ?> <span class="badge badge-success">Active</span> <?php else: ?>  <span class="badge badge-danger">Inactive</span>  <?php endif; ?></td>
            <td><span class="badge badge-info"><?php echo e($user->role); ?></span></td>
            <td>
            <div class="flex">
            <a  href=""><i class="fa fa-user-edit"></i></a> | 
              <a  href=""><i class="fa fa-eye text-success" aria-hidden="true"></i></a> |

              <form action="<?php echo e(route('users.destroy',$user->id)); ?>" class=" d-inline"method="POST"> 
                 <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
              <button type="submit" class="bg-transparent  border-0" ><i class=" text-danger fa fa-trash" aria-hidden="true"></i></button>  
              </form>
            </div>

            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </tbody>
      </table>
    </div>
    <!-- /.card-body -->
    <div class="card-footer clearfix">
      <ul class="pagination pagination-sm m-0 float-right">
        <li class="page-item"><a class="page-link" href="#">«</a></li>
        <li class="page-item"><a class="page-link" href="#">1</a></li>
        <li class="page-item"><a class="page-link" href="#">2</a></li>
        <li class="page-item"><a class="page-link" href="#">3</a></li>
        <li class="page-item"><a class="page-link" href="#">»</a></li>
      </ul>
    </div>
  </div>
</div>

  <?php if($message = Session::get('success')): ?>
  <script>
     Toast.fire({
        icon: 'success',
        title: "<?php echo e($message); ?>"
      });
  </script>  
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\resources\views/admin/users.blade.php ENDPATH**/ ?>