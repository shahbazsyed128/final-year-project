
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="container-fluid">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Courses</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Courses</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <div class="card">
            <div class="card-header">
                <div class="float-right">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isUser')): ?>
                        <a href="<?php echo e(route('courses.create')); ?>" class="btn btn-primary btn-flat">Start Course</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body p-0">
                <table class="table table-hover table-striped ">
                    <thead>
                        <tr>
                            <th style="width: 10px">#</th>
                            <th>Name</th>
                            <th>Type</th>
                            <th style="width: 40px">Subject</th>
                            <th>Price</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td><?php echo e($course->name); ?></td>
                                <td><?php echo e($course->category->name); ?></td>
                                <td><span class="badge badge-info"><?php echo e($course->subject); ?></span></td>
                                <td><span class="badge badge-info"><?php echo e($course->price); ?></span></td>
                                <td>
                                    <?php if($course->status): ?> <span
                                            class="badge badge-success">Active</span>
                                    <?php else: ?> <span class="badge badge-danger">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="flex">
                                        <a href="<?php echo e(route('courses.edit', $course->id)); ?>"><i
                                                class="fa fa-user-edit"></i></a> |
                                        <a href="<?php echo e(route('courses.show', $course->id)); ?>"><i
                                                class="fa fa-eye text-success" aria-hidden="true"></i></a> |

                                        <form action="<?php echo e(route('courses.destroy', $course->id)); ?>" class=" d-inline"
                                            method="POST" id="deletecourse<?php echo e($course->id); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="button" onclick="ConfirmDelete(<?php echo e($course->id); ?>)"
                                                class="bg-transparent  border-0"><i class=" text-danger fa fa-trash"
                                                    aria-hidden="true"></i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <th colspan="7" class="bg-light">
                                    <p class="text-center mb-0">
                                        <a class="text-primary" href="<?php echo e(route('courses.create')); ?>">Start your first
                                            course</a>
                                    </p>
                                </th>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
            <div class="card-footer clearfix">
                <ul class="pagination pagination-sm m-0 float-right">
                    <?php echo e($data->links()); ?>

                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        function ConfirmDelete(id) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire(
                        'Deleted!',
                        'Your Record has been deleted.',
                        'success'
                    );
                    $("#deletecourse" + id).submit();

                }
            })
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\resources\views/courses/courses.blade.php ENDPATH**/ ?>