
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">View Quiz</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('quiz')); ?>">Quiz</a></li>
                        <li class="breadcrumb-item active">View</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>

    <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <div class="container">
        <div class="card card-primary p-4">
            <div class="row">
                <div class="col-md-6">
                    <h4><i class="fa fa-info"></i> View Details</h4>
                </div>
                <div class="col-md-6 text-right">
                    <a href="<?php echo e(route('questions', $quiz['id'])); ?>" class="btn btn-info btn-sm"> Questions</a>
                    <a class="btn btn-primary btn-sm" href="<?php echo e(route("quiz.edit", $quiz['id'])); ?>" title="Edit Quiz"><i class="fa fa-edit"></i></a>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label class="col-form-label"><i class="fas fa-book"></i> Title</label>
                        <div class="color-palette-set">
                            <div class="bg-lightblue color-palette"><span><?php echo e($quiz['title']); ?></span></div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label class="col-form-label"><i class="fa fa-question-circle" aria-hidden="true"></i> Total Questions</label>
                        <div class="color-palette-set">
                            <div class="bg-lightblue color-palette"><span><?php echo e($quiz['total_questions']); ?></span></div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label class="col-form-label"><i class="fa fa-check-circle" aria-hidden="true"></i> Number of options</label>
                        <div class="color-palette-set">
                            <div class="bg-lightblue color-palette"><span><?php echo e($quiz['number_of_options']); ?></span></div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label class="col-form-label"><i class="fa fa-clock"></i> Duration in minutes</label>
                        <div class="color-palette-set">
                            <div class="bg-lightblue color-palette"><span><?php echo e($quiz['duration']); ?></span></div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label class="col-form-label"><i class="fas fa-book-open"></i> Course</label>
                        <div class="color-palette-set">
                            <div class="bg-lightblue color-palette"><span><?php echo e($quiz['course']['name']); ?></span></div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label class="col-form-label"><i class="fas fa-info-circle"></i> Status</label>
                        <div class="color-palette-set">
                            <div class="<?php echo e(($quiz['status_id'] == 1)?'bg-success':'bg-danger'); ?> color-palette"><span><?php echo e($quiz['status']['title']); ?></span></div>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header bg-secondary">
                            Questions
                        </div>
                        <div class="card-body">

                            <?php $__empty_1 = true; $__currentLoopData = $quiz['questions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <h5 class="card-title">Q.<?php echo e(++$key); ?> - <?php echo e($question['question']); ?></h5>

                            <?php $__currentLoopData = $question['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="card-text"><?php echo e(chr($i+65)); ?>). <?php echo e($option['option']); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <p class="card-text font-weight-bold"><span class="text-teal" style="font-size:16px">Answer:</span> Option <?php echo e($question['answer']); ?></p>
                            <hr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>There is no question available in this quiz! please add <a href='<?php echo e(route('questions', $quiz['id'])); ?>'>questions</a>.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.3.0/jquery.form.min.js" integrity="sha512-YUkaLm+KJ5lQXDBdqBqk7EVhJAdxRnVdT2vtCzwPHSweCzyMgYV/tgGF4/dCyqtCC2eCphz0lRQgatGVdfR0ww==" crossorigin="anonymous"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\resources\views/quiz/view.blade.php ENDPATH**/ ?>