
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="container-fluid">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Job Data</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="/home">Home</a></li>
                            <li class="breadcrumb-item active">Job</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card">
                <div class="card-header">
                    <?php echo e($job['category']['name']); ?>

                </div>
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($job['name']); ?></h5>
                    <p class="card-text"><?php echo e($job['description']); ?></p>
                    <p>Applied on: <span
                            class="badge badge-warning"><?php echo e(date('d-M-Y', strtotime($job['pivot']['created_at']))); ?></span>
                    </p>
                    <p>Status:
                        <?php if($job['pivot']['status'] == 'Applied'): ?>
                            <span class="badge badge-warning">Pending</span>
                        <?php elseif($job['pivot']['status'] == 'Hired'): ?>
                            <span class="badge badge-success">Hired</span>
                            <br>
                            Hired on: <span
                                class="badge badge-warning"><?php echo e(date('d-M-Y H:i:s a', strtotime($job['pivot']['updated_at']))); ?></span>
                        <?php elseif($job['pivot']['status'] == 'Rejected'): ?>
                            <span class="badge badge-danger">Rejected</span>
                        <?php endif; ?>
                    </p>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card">
                <div class="card-body">
                    <p class="card-text">There are no jobs available at the moment.</p>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\resources\views/user/applied-jobs.blade.php ENDPATH**/ ?>