
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="container-fluid">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">User Profile</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">User</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-3">

                        <!-- Profile Image -->
                        <div class="card card-primary card-outline">
                            <div class="card-body box-profile">
                                <div class="text-center">
                                    <img class="profile-user-img img-fluid img-circle" src="<?php echo e(asset('img/logo.jpg')); ?>"
                                        alt="User profile picture">
                                </div>

                                <h3 class="profile-username text-center"> <?php echo e($user->name); ?></h3>

                                <p class="text-muted text-uppercase text-center"> <?php echo e($user->role); ?></p>

                                <ul class="list-group list-group-unbordered mb-3">
                                    <li class="list-group-item">
                                        <b>Cource Enrolled</b> <a class="float-right"><?php echo e($courses_enrolled ?? 0); ?></a>
                                    </li>
                                    <li class="list-group-item">
                                        <b>Course Completed</b> <a class="float-right"><?php echo e($courses_completed ?? 0); ?></a>
                                    </li>
                                    <li class="list-group-item">
                                        <b>Course Published</b> <a class="float-right"><?php echo e($courses_published ?? 0); ?></a>
                                    </li>
                                    <li class="list-group-item">
                                        <b>Course Sold</b> <a class="float-right"><?php echo e($courses_sold ?? 0); ?></a>
                                    </li>
                                </ul>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->

                    </div>
                    <!-- /.col -->
                    <div class="col-md-9">
                        <div class="card">
                            <div class="card-header p-2">
                               <h5>User Details</h5>
                            </div><!-- /.card-header -->
                            <div class="card-body">
                                <div class="tab-pane">
                                    <!-- The timeline -->
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <h3 class="text-primary"><i class="fas fa-school"></i> Matriculation
                                                </h3>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <p><span class="font-weight-bold"><?php echo e($user->school ?? ''); ?></span>
                                                        <br />
                                                        Group: <?php echo e($user->ssc_group ?? ''); ?>

                                                        <br />
                                                        Passing Year: <?php echo e($user->ssc_year ?? ''); ?>

                                                        <br />
                                                        Percentage: <?php echo e($user->ssc_percentage ?? ''); ?>

                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <h3 class="text-primary"><i class="fas fa-university"></i> Intermediate
                                                </h3>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <p><span class="font-weight-bold"><?php echo e($user->collage ?? ''); ?></span>
                                                        <br />
                                                        Group: <?php echo e($user->hsc_group ?? ''); ?>

                                                        <br />
                                                        Passing Year: <?php echo e($user->hsc_year ?? ''); ?>

                                                        <br />
                                                        Percentage: <?php echo e($user->hsc_percentage ?? ''); ?>

                                                    </p>
                                                </div>
                                            </div>
                                        </div>

                                        <hr>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <h3 class="text-primary"><i class="fas fa-user-graduate"></i> Graduation
                                                    / Masters</h3>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <p><span class="font-weight-bold"><?php echo e($user->grad_uni ?? ''); ?></span>
                                                        <br />
                                                        Degree: <?php echo e($user->grad_degree ?? ''); ?>

                                                        <br />
                                                        Passing Year: <?php echo e($user->grad_year ?? ''); ?>

                                                        <br />
                                                        Percentage: <?php echo e($user->grad_percentage ?? ''); ?>

                                                    </p>
                                                </div>
                                            </div>
                                        </div>

                                        <hr>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <h3 class="text-primary"><i class="fas fa-user-graduate"></i> Experience
                                                </h3>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div id="exp-div">
                                                    <?php
                                                        $i = 1;
                                                    ?>
                                                    <?php if($user->experiences): ?>
                                                        <?php if(count($user->experiences) >= 1): ?>
                                                            <?php $__currentLoopData = $user->experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $expereicne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div class="row" id="exp-row<?php echo e($key); ?>">
                                                                    <div class="col-sm-12">
                                                                        <p>
                                                                            <span class="font-weight-bold"><?php echo e($expereicne['company_name'] ?? ''); ?></span>
                                                                            <br>
                                                                            <span class="">Postion: <?php echo e($expereicne['position'] ?? ''); ?></span>
                                                                            <br>
                                                                            <span class="">Duration: <?php echo e($expereicne['exp_month']??0); ?> Months</span>
                                                                        </p>
                                                                        <hr>
                                                                    </div>
                                                                </div>
                                                                <?php
                                                                    $i = $i + 1;
                                                                ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <!-- /.tab-content -->
                            </div><!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\resources\views/Company/view-user.blade.php ENDPATH**/ ?>