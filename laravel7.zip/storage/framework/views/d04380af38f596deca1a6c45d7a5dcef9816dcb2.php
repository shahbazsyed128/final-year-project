
<?php $__env->startSection('content'); ?>
     <!-- Content Header (Page header) -->
     <div class="content-header">
      <div class="container-fluid">
          <div class="row mb-2">
          <div class="col-sm-6">
              <h1 class="m-0">Pending Users</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Pending Users</li>
              </ol>
          </div><!-- /.col -->
          </div><!-- /.row -->
      </div><!-- /.container-fluid -->
  </div>
<div class="card">
  <div class="card-body">
    <table class="table table-bordered">
      <thead>
        <tr>
          <th style="width: 10px">#</th>
          <th>Name</th>
          <th>Email</th>
          <th style="width: 40px">Role</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
      <?php if(count($data)>0): ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e(++$i); ?></td>
          <td><?php echo e($user->name); ?></td>
          <td><?php echo e($user->email); ?></td>
          <td>
                <label class="badge badge-success"></label>
            
          </td>
          <td>
            <a  href="<?php echo e(route('users.destroy',$user->id)); ?>"  onclick="ConfirmDelete(event)" data-toggle="tooltip" title="Reject & Delete" ><i class="fas fa-window-close text-danger"></i></a> | 
            <a  href="<?php echo e(route('users.approve',$user->id)); ?>" data-toggle="tooltip" title="Approve" ><i class="fa fa-check text-success" aria-hidden="true"></i></a> 
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <tr>
          <th colspan="5" class="bg-light"><p class="text-center text-primary mb-0">There is no Remaining pending Users</p></th>
        </tr>
        <?php endif; ?>
       
      </tbody>
    </table>
  </div>
  <!-- /.card-body -->
  <div class="card-footer clearfix">
    <ul class="pagination pagination-sm m-0 float-right">
      <?php echo e($data->links()); ?>

    </ul>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\resources\views/user/pending_user.blade.php ENDPATH**/ ?>