
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="container-fluid">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Job Applications</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="/home">Home</a></li>
                            <li class="breadcrumb-item active">Job</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <?php $__empty_1 = true; $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php $__currentLoopData = $application['user_application']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <div class="card-header">
                        <?php echo e($application['category']['name']); ?>

                    </div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($application['name']); ?></h5>
                        <h5 class="card-title">Applicant: <a href="<?php echo e(route('company.user.view', $user['id'])); ?>"
                                data-toggle="tooltip" title="View Profile"><?php echo e($user['name']); ?></a></h5>
                        <p>Applied on: <span
                                class="badge badge-warning"><?php echo e(date('d-M-Y H:i:s a', strtotime($user['pivot']['created_at']))); ?></span>
                            </br>
                            Status:
                            <?php if($user['pivot']['status'] == 'Applied'): ?>
                                <span class="badge badge-warning">Pending</span>
                            <?php elseif($user['pivot']['status'] == 'Hired'): ?>
                                <span class="badge badge-success">Hired</span>
                                <br>
                                Hired on: <span
                                    class="badge badge-warning"><?php echo e(date('d-M-Y H:i:s a', strtotime($user['pivot']['updated_at']))); ?></span>
                            <?php elseif($user['pivot']['status'] == 'Rejected'): ?>
                                <span class="badge badge-danger">Rejected</span>
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="card-footer text-right">
                        <?php if($user['pivot']['status'] == 'Applied'): ?>
                            <a href="<?php echo e(route('company.user.reject', [$user['id'], $application['id']])); ?>" class="btn btn-danger btn-flat btn-sm">Reject</a>
                            <a href="<?php echo e(route('company.user.hire', [$user['id'], $application['id']])); ?>"
                                class="btn btn-success btn-flat btn-sm">Hire</a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card">
                <div class="card-body">
                    <p class="card-text">Post your first job.</p>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\resources\views/Company/job-applications.blade.php ENDPATH**/ ?>