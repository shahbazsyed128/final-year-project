
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="container-fluid">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">All Courses</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="/home">Home</a></li>
                            <li class="breadcrumb-item active">Courses</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <div class="card">
            <div class="card-header">
                <h3>View All courses</h3>
            </div>
            <div class="card-body p-0">
                <div class="row card-deck p-2">
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <div class="card-body">
                                <img src="<?php echo e(asset('img/course-cover.jpg')); ?>" class="card-img-top" alt="...">
                                <h4 class="card-title font-weight-bold mt-2"><?php echo e($course->name); ?></h4>
                                <p class="card-text"><?php echo e(\illuminate\Support\Str::limit($course->summary, 50, '...')); ?>

                                </p>
                                <?php if(!$course['registered_course_count']): ?>
                                    <h6><strong> <?php echo e(number_format($course->price)); ?></strong></h6>
                                    <a href="<?php echo e(route('user.checkout', $course->id)); ?>"
                                        class="btn btn-block btn-outline-primary btn-sm float-right">Buy Now</a>
                                <?php else: ?>
                                    <span class="badge badge-warning rounded-0">
                                        Purchased
                                    </span>
                                    <h6>
                                        <a class="btn btn-block btn-outline-primary btn-sm" href="<?php echo e(route('user.view-course', $course->id)); ?>">Go to course now</a>
                                    </h6>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <!-- /.card-body -->
            <div class="card-footer clearfix">
                <ul class="pagination pagination-sm m-0 float-right">
                    <?php echo e($courses->links()); ?>

                </ul>
            </div>
        </div>



    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('scripts'); ?>
        <script>

        </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\resources\views/student/view-courses.blade.php ENDPATH**/ ?>