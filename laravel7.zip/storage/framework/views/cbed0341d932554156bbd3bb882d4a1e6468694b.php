
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="container-fluid">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Job Data</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Job</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if(!isset($job['user_application'][0]['pivot']['status'])): ?>
                <div class="card">
                    <div class="card-header">
                        <?php echo e($job['category']['name']); ?>

                    </div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($job['name']); ?></h5>
                        <p class="card-text"><?php echo e($job['description']); ?></p>
                        <?php if($job['user_application_count']): ?>
                            <p>Applied on: <span
                                    class="badge badge-warning"><?php echo e(date('d-M-Y', strtotime($job['user_application'][0]['pivot']['created_at']))); ?></span>
                            </p>
                            <p>Status: <span
                                    class="badge badge-primary"><?php echo e($job['user_application'][0]['pivot']['status'] ?? ''); ?></span>
                            </p>
                        <?php else: ?>
                            <a href="<?php echo e(route('job.apply', $job['id'])); ?>" class="btn btn-primary">Apply for this job</a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card">
                <div class="card-body">
                    <p class="card-text">There are no jobs available at the moment.</p>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\resources\views/jobs/user-view.blade.php ENDPATH**/ ?>