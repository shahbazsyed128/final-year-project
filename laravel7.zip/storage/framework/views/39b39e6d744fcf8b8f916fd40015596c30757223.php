
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="container-fluid">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Quiz</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="/home">Home</a></li>
                            <li class="breadcrumb-item active">Quiz</li>
                            <li class="breadcrumb-item active">Test</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <div class="card">
            <div class="card-header row">
                <div class="col-md-6">
                    <h3><?php echo e($quiz['title']); ?></h3>
                </div>
                <div class="col-md-6 text-right">
                    <a href="<?php echo e(route('user.view-course', $quiz['course_id'])); ?>" class="">Back to Course</a>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="container" id="instructions">
                    <div class="jumbotron jumbotron-fluid">
                        <div class="container">
                            <h1 class="display-4"><?php echo e($quiz['title']); ?></h1>
                            <div class="div-test-instruction">
                                <h6 class="text-danger font-weight-bold mx-uline">Instructions:</h6>
                                <ul class="ul-test-instruction">
                                    <li>Total number of questions : <b><?php echo e($quiz['total_questions']); ?></b>.</li>
                                    <li>Time alloted : <b><?php echo e($quiz['duration']); ?></b> minutes.</li>
                                    <?php if(!$quiz['incorrect_mark']): ?>
                                        <li>Each question carry <?php echo e($quiz['correct_mark']); ?> mark, no negative marks.</li>
                                    <?php else: ?>
                                        <li>Each question carry <?php echo e($quiz['correct_mark']); ?> mark.</li>
                                        <li>Negative marking: -<?php echo e($quiz['incorrect_mark']); ?> mark.</li>
                                    <?php endif; ?>
                                    <li>In order to pass the test you have to get atleast
                                        <b><?php echo e($quiz['passing_marks']); ?>%</b>
                                    </li>
                                    <li>DO NOT refresh the page.</li>
                                    <li>All the best :-).</li>
                                </ul>
                            </div>
                            <div class="text-center">
                                <button class="btn btn-primary" id="startTest">Start Test</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container question-container d-none" id="quiz">
                    <div class="card-header text-right text-danger" id="quiz-header">Time Left: <span
                            class="countdown"><?php echo e($quiz['duration']); ?></span></div>
                    <form id="quizSubmit" action="<?php echo e(route('user.submit_quiz')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="quiz_id" value="<?php echo e($quiz['id']); ?>">
                        <?php $__currentLoopData = $quiz['questions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="question ml-sm-5 pl-sm-5 pt-2" id="questionBox">
                                <div class="py-2 h5">
                                    <b><?php echo e('Q.' . ++$key); ?> &nbsp; <?php echo e($question['question']); ?></b>
                                </div>
                                <div class="" id="options">
                                    <ul class="list-unstyled">
                                        <?php $__currentLoopData = $question['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <label class="options"><?php echo e($option['option']); ?>

                                                    <input type="radio" name="option[<?php echo e($question['id']); ?>]"
                                                        value="<?php echo e(chr($i + 65)); ?>">
                                                    <span class="checkmark"></span>
                                                </label>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="card-footer">
                            <div class="text-center">
                                <button class="btn btn-success">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="container question-container d-none" id="results">
                    <div class="card-header">Test Results</div>
                    <table cellspacing="0" cellpadding="4"
                        style="font-size:12px; border:2px solid #ddf8c2; background-color:#fafafa;" width="100%">
                        <tbody>
                            <tr>
                                <td class="text-center font-weight-bold" bgcolor="#ddf8c2" colspan="3" id="obMarks">Marks :
                                    0/20 </td>
                            </tr>
                            <tr>
                                <td>Total number of questions</td>
                                <td width="1%">:</td>
                                <td width="10%" class="text-right font-weight-bold"><?php echo e($quiz['total_questions']); ?></td>
                            </tr>
                            <tr>
                                <td>Number of answered questions</td>
                                <td width="1%">:</td>
                                <td class="font-weight-bold text-right" id="answeredQuestions"></td>
                            </tr>
                            <tr>
                                <td>Number of unanswered questions</td>
                                <td width="1%">:</td>
                                <td class="font-weight-bold text-right" id="unAnsweredQuestions"></td>
                            </tr>
                            <tr>
                                <td>Correct answers</td>
                                <td width="1%">:</td>
                                <td class="font-weight-bold text-right" id="correctAnswers"></td>
                            </tr>
                            <tr>
                                <td>Incorrect answers</td>
                                <td width="1%">:</td>
                                <td class="font-weight-bold text-right" id="incAnswers"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('scripts'); ?>
        <script>
            let current_question = null;
            $("#startTest").click(function() {
                countDown();
                $("#instructions").toggleClass('d-none');
                $("#quiz").toggleClass('d-none');
            });

            function countDown() {
                var timer2 = "<?php echo e($quiz['duration']); ?>:0";
                var interval = setInterval(function() {
                    var timer = timer2.split(':');
                    var minutes = parseInt(timer[0], 10);
                    var seconds = parseInt(timer[1], 10);
                    --seconds;
                    minutes = (seconds < 0) ? --minutes : minutes;
                    if (minutes < 0) {
                        $("#quizSubmit").submit();
                        clearInterval(interval)
                    };
                    seconds = (seconds < 0) ? 59 : seconds;
                    seconds = (seconds < 10) ? '0' + seconds : seconds;
                    $('.countdown').html(minutes + ':' + seconds);
                    timer2 = minutes + ':' + seconds;
                }, 1000);
            }

            $("#quizSubmit").submit(function(e) {
                e.preventDefault();
                let form = document.getElementById('quizSubmit');
                let formData = new FormData(form);
                $.ajax({
                    url: "<?php echo e(route('user.submit_quiz')); ?>",
                    type: "POST",
                    data: formData,
                    contentType: false,
                    processData: false
                }).done(function(response, textStatus, jqXHR) {
                    try {
                        json_response = JSON.parse(response);
                        if (json_response.results) {
                            let results = json_response.results;
                            $("#quiz").addClass("d-none");
                            $("#results").removeClass('d-none');
                            $("#obMarks").text("Marks : " + results['obMarks'] +
                                " / <?php echo e($quiz['total_questions']); ?>");
                            $("#answeredQuestions").text(results['answeredQuestions']);
                            $("#unAnsweredQuestions").text(results['unAnsweredQuestions']);
                            $("#correctAnswers").text(results['correctAnswers']);
                            $("#incAnswers").text(results['incAnswers']);
                        } else if (json_response.error) {
                            Swal.fire(
                                'Error!',
                                json_response.error,
                                'error'
                            )
                        }
                    } catch (e) {
                        Swal.fire(
                            'Error!',
                            "An error occured",
                            'error'
                        )
                    }
                }).fail(function(jqXHR, textStatus, errorThrown) {
                    Swal.fire(
                        'Error!',
                        "Err! Failed to submit test please try again",
                        'error'
                    )
                });
            });
        </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel7\resources\views/student/test.blade.php ENDPATH**/ ?>