<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HiredUser extends Model
{
    //
}
