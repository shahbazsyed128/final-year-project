<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('role')->default('user');
            $table->string('school')->nullable();
            $table->string('ssc_group')->nullable();
            $table->string('ssc_year')->nullable();
            $table->string('ssc_percentage')->nullable();
            $table->string('collage')->nullable();
            $table->string('hsc_group')->nullable();
            $table->string('hsc_year')->nullable();
            $table->string('hsc_percentage')->nullable();
            $table->string('grad_uni')->nullable();
            $table->string('grad_degree')->nullable();
            $table->string('grad_year')->nullable();
            $table->string('grad_percentage')->nullable();
            $table->string('experiences')->nullable();
            $table->tinyInteger('status')->default(0);
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
